<?php
    $user = Auth::user();
    $role = $user->role;

    // Menu per role, sesuai routes/web.php
    $menus = [
        'admin' => [
            ['label' => 'Dashboard',          'route' => 'admin.dashboard',              'active' => 'admin.dashboard'],
            ['label' => 'Kategori Konsultan', 'route' => 'admin.kategori.index',         'active' => 'admin.kategori.*'],
            ['label' => 'Topik Konsultasi',   'route' => 'admin.topik.index',            'active' => 'admin.topik.*'],
            ['label' => 'Kelola Konsultan',   'route' => 'admin.konsultan-profil.index', 'active' => 'admin.konsultan-profil.*'],
            ['label' => 'Akun Pengguna',      'route' => 'admin.users.index',            'active' => 'admin.users.*'],
            ['label' => 'Cetak Laporan',      'route' => 'admin.laporan.index',          'active' => 'admin.laporan.*'],
            ['label' => 'Pantau Percakapan',  'route' => 'admin.pemantauan.index',       'active' => 'admin.pemantauan.*'],
        ],
        'konsultan' => [
            ['label' => 'Dashboard', 'route' => 'konsultan.dashboard', 'active' => 'konsultan.dashboard'],
            ['label' => 'Obrolan',   'route' => 'konsultan.obrolan',   'active' => 'konsultan.obrolan'],
        ],
        'audiens' => [
            ['label' => 'Dashboard',       'route' => 'audiens.dashboard',       'active' => 'audiens.dashboard'],
            ['label' => 'Pilih Konsultan', 'route' => 'audiens.pilih-konsultan', 'active' => 'audiens.pilih-konsultan'],
            ['label' => 'Konsultasi Saya', 'route' => 'audiens.konsultasi-saya', 'active' => 'audiens.konsultasi-saya'],
        ],
    ];

    $menuItems = $menus[$role] ?? $menus['audiens'];

    // Foto avatar: konsultan dari profil konsultan, lainnya dari akun user
    $profilKonsultan = $role === 'konsultan' ? ($user->konsultanProfil ?? null) : null;
    $fotoNav = $profilKonsultan?->foto_profil
        ? asset('storage/' . $profilKonsultan->foto_profil)
        : ($user->foto_profil ? asset('storage/' . $user->foto_profil) : null);
?>

<style>
    .nav-biru-item {
        display: block;
        padding: 14px 24px;
        color: #ffffff;
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        white-space: nowrap;
        transition: background 0.15s ease;
    }
    .nav-biru-item:hover { background: #3F86D3; }
    .nav-biru-item.aktif { background: #0A8CFF; }
</style>

<nav x-data="{ open: false }" class="bg-white">

    
    <div style="max-width: 80rem; margin: 0 auto; padding: 12px 24px; display: flex; align-items: center; justify-content: space-between;">

        <a href="<?php echo e(route('dashboard')); ?>" style="display: flex; align-items: center; gap: 12px; text-decoration: none;">
            <img src="<?php echo e(asset('images/logo-bpkp.png')); ?>" alt="Logo BPKP" style="height: 42px; width: auto;">
            <span class="hidden sm:block" style="font-size: 14px; font-weight: 700; color: #111827;">
                BPKP Perwakilan Sulawesi Selatan
            </span>
        </a>

        <div style="display: flex; align-items: center; gap: 20px;">

            
            <button type="button" title="Notifikasi"
                    style="background: none; border: 0; cursor: pointer; padding: 4px; color: #111827;">
                <svg style="width: 22px; height: 22px;" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"/>
                </svg>
            </button>

            
            <div class="hidden sm:block">
                <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                     <?php $__env->slot('trigger', null, []); ?> 
                        <button type="button" style="display: flex; align-items: center; gap: 12px; background: none; border: 0; cursor: pointer; padding: 0;">
                            <?php if($fotoNav): ?>
                                <img src="<?php echo e($fotoNav); ?>" alt="<?php echo e($user->name); ?>"
                                     style="width: 46px; height: 46px; border-radius: 9999px; object-fit: cover; background: #D1D5DB;">
                            <?php else: ?>
                                <span style="width: 46px; height: 46px; border-radius: 9999px; background: #D1D5DB; display: flex; align-items: center; justify-content: center; color: #111827;">
                                    <svg style="width: 22px; height: 22px;" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"/>
                                    </svg>
                                </span>
                            <?php endif; ?>

                            <span style="font-size: 17px; font-weight: 700; color: #111827;"><?php echo e($user->name); ?></span>

                            <svg style="width: 16px; height: 16px; color: #6B7280;" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </button>
                     <?php $__env->endSlot(); ?>

                     <?php $__env->slot('content', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                            <?php echo e(__('Profile')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>

                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        </form>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
            </div>

            
            <button @click="open = ! open" class="sm:hidden" type="button"
                    style="background: none; border: 0; cursor: pointer; padding: 6px; color: #6B7280;">
                <svg style="width: 26px; height: 26px;" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
    </div>

    
    <div class="hidden sm:block" style="background: #1D6BC0; box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
        <div style="max-width: 80rem; margin: 0 auto; padding: 0 24px; display: flex; flex-wrap: wrap;">
            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route($item['route'])); ?>"
                   class="nav-biru-item <?php echo e(request()->routeIs($item['active']) ? 'aktif' : ''); ?>">
                    <?php echo e($item['label']); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden" style="background: #1D6BC0;">
        <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>"
               class="nav-biru-item <?php echo e(request()->routeIs($item['active']) ? 'aktif' : ''); ?>">
                <?php echo e($item['label']); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div style="border-top: 1px solid rgba(255,255,255,0.25); padding: 12px 0;">
            <div style="padding: 0 24px 8px 24px; color: #ffffff;">
                <div style="font-weight: 700; font-size: 14px;"><?php echo e($user->name); ?></div>
                <div style="font-size: 12px; opacity: 0.85;"><?php echo e($user->email); ?></div>
            </div>

            <a href="<?php echo e(route('profile.edit')); ?>" class="nav-biru-item">Profile</a>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('logout')); ?>" class="nav-biru-item"
                   onclick="event.preventDefault(); this.closest('form').submit();">
                    Log Out
                </a>
            </form>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\apk-bpkp-main\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>